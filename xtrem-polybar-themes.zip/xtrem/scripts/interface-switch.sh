#!/usr/bin/env bash

SDIR="$HOME/.config/polybar/xtrem/scripts"
FILE="$SDIR/interface.conf"

change_interface()
{
	echo -e "interface:\t$1" > $FILE
}

# Launch Rofi
MENU="$(rofi -no-config -no-lazy-grab -sep "|" -dmenu -i -p '' \
-theme $SDIR/rofi/interface.rasi \
<<< " Eth0| Eth1| Eth2| VPN")"
            case "$MENU" in
				*Eth0) change_interface "eth0" ;;
				*Eth1) change_interface "eth1" ;;
				*Eth2) change_interface "eth2" ;;
				*VPN) change_interface "tun0" ;;
            esac
